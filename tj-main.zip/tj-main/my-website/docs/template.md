# Template

```html
class="<device>@<theme>.<selector>:<property>_<value>"
[Devices: phone, tablet, laptop, and pc]
[Themes: light and dark]
[Spaces in <value> may be represented by "~"]
[Variables in <value> may be represented by "--name" instead of "var(--name)"]
[Chaining of selectors is possible, you can do things like "hover:before:*"]
———
<device> | Device Media Queries (optional)
<mode> | Mode Media Queries (optional)
<selector> | CSS Selectors (optional)
<property> | CSS Properties
<value> | value of said properties
```

## Property–Value
The property–value template represents the relation between a property and its value in CSS, e.g 
```css
border-radius: 50%
``` 
Here, "border-radius" represents the property while "50%" represents the value.

Now here's the same thing with Synxia:
```html
class="border-radius_50%"
```

As can be seen above, "border-radius" is the property and "50%" is the value with "_" acts as a separator between them.

### Spaces

But what if I need spaces? Well, you don't need to worry just yet!

Spaces in the value can be represented by "~". For example, 
```css
background: red !important
```
would translate to
```html
class="background_red~!important"
```

Got the hang of it yet?

### CSS Variables

What about variables, wouldn't it get hectic if things like
```css
content: var(--divContent)
```
were reused a ton of times?

Well, yes—and that's exactly why you don't need to do
```html
class="content_var(--divContent)"
```
You can just do this instead
```html
class="content_--divContent"
```

## CSS Selectors

CSS Selectors are what I call the ":/::" selectors/psuedoelements (hover, before, marked...)

A Synxia example like 
```html
class="hover:background-image_url(...)"
```
would generate
```css
tooLongToWrite:hover {
    background-image: url(...)
}
```
Noticed something yet?

Here ":" is the common separator; selectors are the third in order if we go backwards.


### Selector Chaining 

But how would I chain selectors, you know... like Tailwind does it?

Well, if your was aim is to have "::before" content appear upon hovering—you'd just have to do this
```html
class="hover:before:content_--divContent"
```

Simple, right?
## Theme Queries 

Theme Queries is just a fancy name for dark mode and light mode support, you know... like Tailwind does it—again.

Here's a syntax example
```html
class="dark.background_--mainColour"
```

"." acts as the separator here.

But where's that on our little order?
Well, going backwards (yet again) would place it at quite a steep fourth place.
```html
class="light.hover:background_--lightHoverAccent"
```


### Types

The types? Yep, you guessed it!
Just "dark" and "light" for now.

## Device Queries 

Finally, we've reached the end of our fantastic journey!
To begin, Device Queries aren't actually dependant on the device; they use the most probable min and max width instead.

Here are some examples as usual
```html
class="phone@font-size_--phoneFontSize
```
Separator --> "@"!

```html
class="tablet@dark.hover:color_--tabletDarkHoverAccent
```

Fifth, or just the last, place :-).

### Types

Types again! Though, this time you might not have guessed right.

The types are: "phone", "tablet", "laptop", and "pc".
