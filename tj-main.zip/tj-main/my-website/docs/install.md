---
slug: /
---
# Installation

Let's discover **Synxia in less than 5 minutes**.

## Getting Started

Get started by **downloading the npm package**.
```bash
npm i synxia
```

Or **try out Synxia immediately** with the official **[CDN](https://cdn.jsdelivr.net/npm/synxia@latest/synxia.js)**.

## Link to HTML

Link **Synxia's source** to your `HTML` files!
```html
<script src="./src/synxia.js"></script>
```
or
```html
<script src="https://cdn.jsdelivr.net/npm/synxia@latest/synxia.js"></script>
```