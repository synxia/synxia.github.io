# Introduction

Synxia is a **runtime** (though a buildtime version is the works), javascript-based framework created by me because I didn't like how Tailwind's vague class system worked and how most of their values were already predefined.

Now, don't get me wrong; oftentimes predefined layouts are easier to stick to... but, that isn't really "atomic" as Adam claims.

So, I made Synxia. While it does have predefined media queries and modes I'm actually planning to add variable support for them; stay tuned for that!

Anywho, let's start with how Synxia truly works under the hood as only then will you be able to understand what Synxia really is.

Synxia employs various tactics to reach its current results, mainly regex and objects—but we'll get to that later. We're going to explain what runtime actually is first after all.

So, what is runtime really? Well... it's just a fancy for the lovely process of instructions executing while the program—or, in our case, browser—is running.

And now that we've explained what runtime is, let's start with the benefits of Synxia being a runtime framework:

First of all, by using `MutationObserver` Synxia supports dynamic classes, simple element manipulation, and DOM mutation. Way better than having to reload the **whole entire page**, right?
