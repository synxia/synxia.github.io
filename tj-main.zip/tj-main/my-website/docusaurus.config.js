// @ts-check
// `@type` JSDoc annotations allow editor autocompletion and type checking
// (when paired with `@ts-check`).
// There are various equivalent ways to declare your Docusaurus config.
// See: https://docusaurus.io/docs/api/docusaurus-config

import {themes as prismThemes} from 'prism-react-renderer';

/** @type {import('@docusaurus/types').Config} */

export default {
  title: 'Synxia',
  url: 'https://synxia.onrender.com/',
  baseUrl: '/',
  tagline: 'CSS–JS Framework',
  favicon: 'img/favicon.png',
  onBrokenLinks: 'throw',
  onBrokenMarkdownLinks: 'warn',
  i18n: {
    defaultLocale: 'en',
    locales: ['en'],
  },
  themeConfig: {
    metadata: [
      {name: 'keywords', content: 'css, js, html, web development, framework, npm, jsdelivr, js framework, javascript'},
      {property: 'twitter:card', content: 'img/favicon.png'},
      {name: 'theme-color', content: '#43B581'},
      {property: 'og:url', content: 'https://synxia.onrender.com'},
      {property: 'og:author', content: 'JokeFat'},
      {property: 'og:site_name', content: 'Synxia'},
      {property: 'og:image', content: 'img/favicon.png'},
    ],
     navbar: {
       title: 'Synxia',
       logo: {
        alt: 'Site Logo',
        src: 'img/logo.svg',
        width: 32,
        height: 32,
       },
    },
      prism: {
        theme: prismThemes.github,
        darkTheme: prismThemes.dracula,
    },
  },
  presets: [
    [
      '@docusaurus/preset-classic',
      {
        docs: {
          routeBasePath: '/',
        },
        blog: false,
      },
    ],
  ],
};
